<?php

namespace Database\Seeders\Admin;

use Illuminate\Database\Seeder;

class SetupEmailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $env_modify_keys = [
            "MAIL_MAILER"       => "smtp",
            "MAIL_HOST"         => "mail.wecard.uk",
            "MAIL_PORT"         => "465",
            "MAIL_USERNAME"     => "info@wecard.uk",
            "MAIL_PASSWORD"     => "appdevs@2023",
            "MAIL_ENCRYPTION"   => "ssl",
            "MAIL_FROM_ADDRESS" => "info@wecard.uk",
            "MAIL_FROM_NAME"    => "we card",
        ];

        modifyEnv($env_modify_keys);
    }
}
